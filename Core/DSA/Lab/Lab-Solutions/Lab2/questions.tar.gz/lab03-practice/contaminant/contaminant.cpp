#include "contaminant.h"

#include <vector>
#include <string>

int recover_original(Node *&head, const string &pattern) {
    // Your code starts from here -- DO NOT EDIT ANYTHING ABOVE



    // Your code ends here -- DO NOT EDIT ANYTHING BELOW
}