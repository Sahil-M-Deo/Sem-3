#include "stack-list.h"

// --- Helper Functions (Already Implemented) ---

// Attempts to push an element into the block; returns false if the block is full.
bool stackBlock::try_push(char x) {
    if (top_idx < BLOCK_SIZE) {
        data[top_idx++] = x;
        return true;
    }
    return false;
}

// Attempts to pop the top element from the block into 'x'; returns false if the block is empty.
bool stackBlock::pop(char& x) {
    if (top_idx > 0) {
        x = data[--top_idx];
        return true;
    }
    return false;
}

// Checks if the current block contains zero elements.
bool stackBlock::empty() const {
    return top_idx == 0;
}

// Initializes an empty stack list with a null head pointer.
stackList::stackList() {
    head = nullptr;
}

// Iterates through the linked list to safely delete all dynamically allocated stack nodes.
stackList::~stackList() {
    stackNode* curr = head;
    while (curr != nullptr) {
        stackNode* next = curr->below;
        delete curr;
        curr = next;
    }
}

// Checks if the entire stack list is empty, accounting for a potentially retained empty head block.
bool stackList::empty() const {
    if (head == nullptr) return true;
    if (head->block.empty() && head->below == nullptr) return true;
    return false;
}

// Traverses the list to print the total block count and the current number of elements in each block.
void stackList::print_blocks() const {
    stackNode* curr = head;
    int count = 0;
    while (curr) { count++; curr = curr->below; }
    
    cout << "Blocks: " << count << " | ";
    curr = head;
    while (curr) {
        cout << "[" << curr->block.top_idx << "] ";
        curr = curr->below;
    }
    cout << endl;
}


// --- Student Implementation Section ---

void stackList::push(char x) {
    // TODO: Push character x onto the stack list, creating a new block if the top is full.
    // Your code starts from here -- DO NOT EDIT ANYTHING ABOVE



    // Your code ends here -- DO NOT EDIT ANYTHING BELOW
}

bool stackList::pop(char& x) {
    // TODO: Pop a character into x. Do not delete the head block if it becomes empty. 
    // Delete the head block only if the block below it becomes empty after a pop.
    // Return true if successful, false if the stack is completely empty.
    // Your code starts from here -- DO NOT EDIT ANYTHING ABOVE



    // Your code ends here -- DO NOT EDIT ANYTHING BELOW
}